#include<iostream>
#include"stack.h"

using namespace std;

int convertor(int number, int base)
{
	StackArray remainder;

	while (number > 0)
	{
		remainder.push(number % base);
		number /= base;
	}
	int rem = 0;

	while (!remainder.isEmpty())
	{
		rem = rem * 10 + remainder.pop();
	}
	return rem;
}

int main()
{
	int number, base;

	cout << "Enter decimal number: ";
	cin >> number;

	cout << "Enter base(2-9): ";
	cin >> base;

	while (base < 2 || base > 9)
	{
		cin >> base;
	}

	int convert = convertor(number, base);

	cout << "Converted decimal = " << convert << endl;

	return 0;
}