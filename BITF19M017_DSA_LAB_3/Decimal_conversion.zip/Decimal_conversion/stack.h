#pragma once

#ifndef STACK_H
#define STACK_H

class StackArray
{
	int* data;
	int size;
	int top;
public:
	StackArray()
	{
		this->top = -1;
		this->size = 10;
		this->data = new int[size];
	}
	StackArray(int s)
	{
		this->top = -1;
		this->size = (s > 0) ? s : 10;
		this->data = new int[size];
	}
	StackArray(const StackArray& ref)
	{
		this->top = ref.top;
		this->size = ref.size;
		this->data = new int[size];

		for (int i = 0; i < size; i++)
		{
			data[i] = ref.data[i];
		}
	}
	StackArray& operator=(const StackArray& ref)
	{
		if (this->data)
			delete[] data;

		this->top = ref.top;
		this->size = ref.size;
		this->data = new int[size];

		for (int i = 0; i < size; i++)
		{
			data[i] = ref.data[i];
		}

		return *this;
	}
	void push(int value)
	{
		if (top == size - 1)
		{
			resize(size * 2);
		}

		data[++top] = value;
	}
	int pop()
	{
		return data[top--];
	}
	int Top()const
	{
		return top;
	}
	bool isEmpty()
	{
		return (top == -1);
	}
	void resize(int s)
	{
		int* newdata = new int[this->size];

		for (int i = 0; i < this->size; i++)
		{
			newdata[i] = data[i];
		}

		delete[] data;

		data = new int[s];
		for (int i = 0; i < this->size; i++)
		{
			data[i] = newdata[i];
		}
		this->size = s;

		delete[] newdata;
		newdata = nullptr;
	}
	~StackArray()
	{
		delete[] data;
		data = nullptr;
	}
};

#endif