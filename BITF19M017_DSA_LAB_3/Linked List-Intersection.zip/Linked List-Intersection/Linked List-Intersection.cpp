#include<iostream>
#include"SLList.h"

using namespace std;

//take comparatively less time
//return result after both the linklist get empty 1 time
//LinkList inter(LinkList& L1, LinkList& L2)
//{
//	LinkList intersec;
//	int value1, value2;
//
//	while (!L1.isEmpty() && !L2.isEmpty())
//	{
//		value1 = L1.RemoveAtTail();
//		value2 = L2.RemoveAtTail();
//
//		if (value1 == value2)
//		{
//			intersec.insertAtTail(value1);
//		}
//		else if (value1 < value2 && !L2.isEmpty())
//		{
//			while (value2 > value1)
//			{
//				value2 = L2.RemoveAtTail();
//				if (L2.isEmpty())
//				{
//					break;
//				}
//			}
//			if (value1 == value2)
//			{
//				intersec.insertAtTail(value1);
//			}
//			else if (value1 > value2)
//			{
//				while (value1 > value2)
//				{
//					value1 = L1.RemoveAtTail();
//					if (L1.isEmpty())
//					{
//						break;
//					}
//				}
//				if (value1 == value2)
//				{
//					intersec.insertAtTail(value1);
//				}
//			}
//		}
//		else if (value2 < value1 && !L1.isEmpty())
//		{
//			while (value1 > value2)
//			{
//				value1 = L1.RemoveAtTail();
//				if (L1.isEmpty())
//				{
//					break;
//				}
//			}
//			if (value1 == value2)
//			{
//				intersec.insertAtTail(value1);
//			}
//			else if (value1 < value2)
//			{
//				while (value2 > value1)
//				{
//					value2 = L2.RemoveAtTail();
//					if (L2.isEmpty())
//					{
//						break;
//					}
//				}
//				if (value1 == value2)
//				{
//					intersec.insertAtTail(value1);
//				}
//			}
//		}
//	}
//
//	if (L1.isEmpty() && !L2.isEmpty())
//	{
//		while (!L2.isEmpty())
//		{
//			value2 = L2.RemoveAtTail();
//			if (value1 == value2)
//			{
//				intersec.insertAtTail(value1);
//				break;
//			}
//		}
//	}
//	if (!L1.isEmpty() && L2.isEmpty())
//	{
//		while (!L1.isEmpty())
//		{
//			value1 = L1.RemoveAtTail();
//			if (value1 == value2)
//			{
//				intersec.insertAtTail(value1);
//				break;
//			}
//		}
//	}
//
//	return intersec;
//}

//program with nested loop.
//take more time with large link list.
//(=) operator call after every outer loop iteration ends.
LinkList intersec(const LinkList& L1, const LinkList& L2)
{
	LinkList result;

	LinkList temp1 = L1;
	while (!temp1.isEmpty())
	{
		LinkList temp2 = L2;
		int value1 = temp1.RemoveAtTail();
		while (!temp2.isEmpty())
		{
			int value2 = temp2.RemoveAtTail();
			if (value1 == value2)
			{
				result.insertAtTail(value1);
			}
		}
	}

	return result;

}

int main()
{
	LinkList L1, L2;
	
	cout << "L1 = 1 6 10 20 30" << endl;
	L1.insertAtTail(1);
	L1.insertAtTail(6);
	L1.insertAtTail(10);
	L1.insertAtTail(20);
	L1.insertAtTail(30);

	cout << "L2 = 1 5 6 7 10 20 30" << endl;
	L2.insertAtTail(1);
	L2.insertAtTail(5);
	L2.insertAtTail(6);
	L2.insertAtTail(7);
	L2.insertAtTail(10);
	L2.insertAtTail(12);
	L2.insertAtTail(20);
	L2.insertAtTail(30);

	LinkList intersection = intersec(L1, L2);

	cout << "\nL1 intersection L2: ";
	while (!intersection.isEmpty())
	{
		cout << intersection.RemoveAtTail() << " ";
	}
	cout << endl;

	return 0;
}
