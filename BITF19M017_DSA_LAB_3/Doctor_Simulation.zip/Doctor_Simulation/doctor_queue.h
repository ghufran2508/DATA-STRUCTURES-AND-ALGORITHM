#pragma once

#ifndef DOCTOR_QUEUE_H
#define DOCTOR_QUEUE_H

#include<iostream>
#include"Patient.h"
#include<string>
#define SIZE 10
using namespace std;

template<class datatype>
class doctor_queue
{
	int front;
	int rear;
	datatype data[10];
public:
	doctor_queue()
	{
		front = rear = -1;
	}
    bool isFull() {
        return ((rear+1)%SIZE == front);
    }
    bool isEmpty() {
        return (front == -1);
    }
    void insert(const Patient& x) {
        if (front == -1 && rear == -1) {
            front = rear = 0;
            data[rear] = x;
        }
        else {
            if ((rear + 1) % SIZE == front) {
                cout << "Full Queue \n";
            }
            else {
                rear = (rear + 1) % SIZE;
                data[rear] = x;
            }
        }
    }

    datatype dequeue() {
        if (isEmpty()) {
            exit(0);
        }
        else {
            datatype rv;
            rv = data[front];
            if (front == rear) {
                front = rear = -1;
            }
            else {
                front = (front + 1) % SIZE;
            }
            return rv;
        }
    }
    void show() {
        int t;
        if (!isEmpty()) {
            t = front;
            while (t <= rear)
                cout << data[t++] << " - ";
        }
        else {
            cout << "No data in queue";
        }
    }
};

#endif // !DOCTOR_QUEUE_H
