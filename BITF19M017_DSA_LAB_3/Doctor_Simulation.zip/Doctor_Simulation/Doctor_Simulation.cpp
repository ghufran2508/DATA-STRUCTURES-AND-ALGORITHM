#include<iostream>
#include"Patient.h"
#include"doctor_queue.h"
#include<string>
using namespace std;

void show(const Patient& rp, const int& count)
{
	system("cls");
	cout << "***************************************" << endl << endl;
	cout << "PAtient In The Doctor Room" << endl;
	cout << "Patient Name: " << rp.getName() << endl;
	cout << "Patient CNIC: " << rp.getCNIC() << endl;
	cout << "Patient age: " << rp.getage() << endl;
	cout << "Patient Turn Number = " << count << endl;
	cout << "\n***************************************" << endl << endl;
}

int main()
{
	string name, cnic;
	int age, count = 0;
	
	Patient nopatient("EMPTY", "EMPTY", 0);
	Patient newpatient;

	doctor_queue<Patient> dq;

	while (1)
	{
		int option;

		if (dq.isEmpty() || count == 0)
		{
			show(nopatient, count);
		}
		if (count > 0)
		{
			show(dq.dequeue(), count);
		}

		cout << "Enter " << endl;
		cout << "\t\t1. For Pass Patient." << endl;
		cout << "\t\t2. For Enter Patient in Queue." << endl;
		cout << "\t\t0. Exit." << endl;
		cout << "\nEnter Your Choice.\t";
		cin >> option;

		if (option == 1)
		{
			count++;
		}
		else if (option == 2)
		{
			cout << "\nENTER PATIENT DETAILS" << endl;
			cout << "Patient Name = ";
			cin.ignore();
			getline(cin, name);
			cout << "Patient CNIC = ";
			cin >> cnic;
			cout << "Patient Age = ";
			cin >> age;

			while (age < 0)
			{
				cin >> age;
			}
			newpatient.setName(name);
			newpatient.setCNIC(cnic);
			newpatient.setage(age);

			dq.insert(newpatient);
		}
		else
		{
			exit(0);
		}
	}

	return 0;
}