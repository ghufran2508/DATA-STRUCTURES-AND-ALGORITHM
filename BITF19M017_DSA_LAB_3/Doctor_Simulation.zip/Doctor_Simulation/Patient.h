#pragma once

#ifndef PATIENT_H
#define PATIENT_H

#include<iostream>
#include<string>

using namespace std;

class Patient
{
private:
	string name;
	string CNIC;
	int age;
public:
	Patient()
	{
		name = "EMPTY";
		CNIC = "EMPTY";
		age = 0;
	}
	Patient(const Patient& ref)
	{
		this->name = ref.name;
		this->CNIC = ref.CNIC;
		this->age = ref.age;
	}
	Patient(string p_name, string p_CNIC, int p_age)   
	{
		this->name = p_name;
		this->CNIC = p_CNIC;
		this->age = (p_age > 0) ? p_age : 0;
	}
	void setName(string p_name)
	{
		this->name = p_name;
	}
	void setCNIC(string p_CNIC)
	{
		this->CNIC = p_CNIC;
	}
	void setage(int p_age)
	{
		this->age = p_age;
	}
	string getName() const
	{
		return this->name;
	}
	string getCNIC() const
	{
		return this->CNIC;
	}
	int getage() const
	{
		return this->age;
	}
	Patient& operator=(const Patient& ref)
	{
		this->name = ref.name;
		this->CNIC = ref.CNIC;
		this->age = ref.age;
		return *this;
	}
	friend ostream& operator<<(ostream& out, const Patient& ref);
};

ostream& operator<<(ostream& out, const Patient& ref)
{
	out << "Patient Name: " << ref.getName() << endl;
	out << "Patient CNIC: " << ref.getCNIC() << endl;
	out << "Patient Age: " << ref.getage() << endl;
	return out;
}

#endif // !PATIENT_H