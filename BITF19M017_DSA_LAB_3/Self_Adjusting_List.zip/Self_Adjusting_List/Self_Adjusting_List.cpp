#include<iostream>
#include"SLList.h"

using namespace std;

int main()
{
	LinkList sll;

	sll.insertAtTail(1);
	sll.insertAtTail(2);
	sll.insertAtTail(3);
	sll.insertAtTail(4);
	sll.insertAtTail(0);

	//function in header file declared at line 341
	sll.self_adjust(0);

	while (!sll.isEmpty())
	{
		cout << sll.RemoveAtHead() << endl;
	}

	return 0;
}